const sequelize = require('../Config/Database')
const { DataTypes } = require('sequelize')

const User = sequelize.define('user',{
    id_user: {type: DataTypes.INTEGER, autoIncrement:true, primaryKey:true},
    name: {type: DataTypes.STRING, allowNull:false},
    email: {type: DataTypes.STRING, allowNull:false},
    password: {type: DataTypes.TEXT, allowNull:false},
    profile_ph: {type: DataTypes.STRING, allowNull:false}
},{
    freezeTableName: true,  // Isso garante que o Sequelize não pluralize o nome da tabela
    tableName: 'user'
})

module.exports = User

// Pergunatar ao meu mano Gustavo pq no SQL cria mais duas tabelas "createdAt" e "updatedAt"