const sequelize = require('../Config/Database')
const User = require('./User')
const { DataTypes } = require('sequelize')

const Image = sequelize.define('image',{
    id_image: {type: DataTypes.INTEGER, autoIncrement:true, primaryKey:true},
    url_imagem: {type: DataTypes.STRING, allowNull:false},
    keyword: {type: DataTypes.STRING, allowNull:false}
},{
    freezeTableName: true,  // Isso garante que o Sequelize não pluralize o nome da tabela
    tableName: 'image'
})

User.hasMany(Image)
Image.belongsTo(User)

module.exports = Image