const express = require('express')
const cors = require('cors')
const routes = require('./routes')

const Image = require('./Model/Image')
const User = require('./Model/User')

const app = express()

app.use(express.json())
app.use(cors())
app.use(routes)

Image.sync()
    .then(() =>{
        console.log('Banco de Dados sincronizado! Tabela Image')
    })
    .catch(() =>{
        console.log('Erro ao sincronizar a Tabela Image')
    })

User.sync()
    .then(() =>{
        console.log('Banco de Dados sincronizado! Tabela User')
    })
    .catch(() =>{
        console.log('Erro ao sincronizar a Tabela User')
    })

app.listen(5000,() =>{
    console.log('Servidor rodando!')
})