// Importante: CREATE DATABASE galeria; comando para criar o nosso database.
// Importante: 'sesi' é a senha do MYSQL no notebook do SESI

const Sequelize = require('sequelize')

const sequelize = new Sequelize('galeria', 'root', 'sesi',{
    host: 'localhost',
    dialect: 'mysql'
})

module.exports = sequelize