const User = require("../Model/User")
const bcrypt = require("bcrypt")

exports.AddUser = async (req,res)=>{
    try {
        const {name,email,password,profile_ph} = req.body
        const passwordHash = await bcrypt.hash(password, 5)
        console.log(name, email, password, profile_ph)

        const user = await User.create({ name, email, password: passwordHash, profile_ph }) 

        res.status(201).json({message:"Usuário cadastrado com sucesso!"})
    }catch (err){
        console.log(err)
    }
}
